<?php

require_once "configs/app.cfg";
require_once "core/Processor.php";
require_once "core/Controller.php";
