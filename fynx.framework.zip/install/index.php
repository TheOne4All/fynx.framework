<?php

/*
|--------------------------------------------------------------------------
| Initial Base Redirect
|--------------------------------------------------------------------------
|
| This rule would redirect any URL request to the PUBLIC directory where
| the system's default base loads files.
|
 */
header("location: public");
