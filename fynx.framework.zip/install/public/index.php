<?php

require_once "../app/init.php";
$processor = new Processor;
