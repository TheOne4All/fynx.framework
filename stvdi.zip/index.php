<?php

    require_once 'system/configs/app.cfg';

    // include autoloader
    // require_once FYNX_SYSTEM['system'] . 'autoloader.php';



    $fynxLogger = $autoLoader->instantiateClass['fynxLogger'];
    // echo $fynxLogger->log( 'Bad Syntax message please try again later', 'Error' ) . ' testing';
    // echo '<br />';
    // var_dump(FYNX_USERCONFIG);

    // echo $fynxLogger->_get_datetime();