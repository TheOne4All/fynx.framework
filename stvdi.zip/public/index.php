<?php

    //require the initialize.ini file to load core Libraries via Autoloader Object
    require_once '../system/mapping/initialize.ini';

    //load the URL Mapper Object
    $mapper = new Mapper;
?>